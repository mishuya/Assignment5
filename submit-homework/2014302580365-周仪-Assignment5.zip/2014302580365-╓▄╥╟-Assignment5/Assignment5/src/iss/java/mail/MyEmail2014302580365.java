package iss.java.mail;

import java.io.IOException;
import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Message.RecipientType;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class MyEmail2014302580365 implements IMailService{
	private Properties p0; 
	private Properties p1;
	private MYMailAuthenticator myAu;
	private Session session0;
	private Session session1;
	
	/**
	 * ����Э�顢�Ի�����֤��Ϣ�ȡ����з����Լ��յ��ʼ�ǰ�����ӹ�����
	 */
	@Override
	public void connect() throws MessagingException {
		p0 = new Properties();
		p1 = new Properties(); 
		p0.put("mail.smtp.auth", "true");
        p0.put("mail.smtp.host", "smtp.163.com");
        p0.setProperty("mail.transport.protocol", "smtp");
		p1.put("mail.store.protocol", "imap");
		p1.put("mail.imap.host", "imap.163.com");
		p1.put("mail.imap.auth", "true");
        p1.setProperty("mail.imap.ssl.enable","true");
		myAu = new MYMailAuthenticator("13006129089@163.com","********");
		session0 = Session.getInstance(p0,myAu);
		session1 = Session.getInstance(p1,myAu);
	}

	/**
	 * �����ʼ���
	 */
	@Override
	public void send(String recipient, String subject, Object content)
			throws MessagingException {
		MimeMessage message = new MimeMessage(session0);
		message.setFrom(new InternetAddress("13006129089@163.com"));
		message.setRecipient(RecipientType.TO, new InternetAddress(recipient));
		message.setSubject(subject);
		message.setContent(content.toString(),"text/html;charset=utf-8");
		Transport.send(message);
	}

	/**
	 * �����ʼ��Ƿ��������͵�Ŀ�����䡣
	 */
	@Override
	public boolean listen() throws MessagingException {
		Store store1 = session1.getStore();
        store1.connect();
		Folder folder = store1.getFolder("inbox");
		folder.open(Folder.READ_ONLY);
		if(folder.getNewMessageCount() > 0){
			return true;
		}else{
			return false;
		}
	}

	/**
	 * �õ��ռ������յ����ʼ����ݵ������Ϣ��
	 */
	@Override
	public String getReplyMessageContent(String sender, String subject)
			throws MessagingException, IOException {
		Store store = session1.getStore();
		store.connect();
		String feedback = " ";
		Folder folder = store.getFolder("inbox");
		folder.open(Folder.READ_ONLY);
		Message[] allMessage = folder.getMessages();
		for(int i = 0;i < allMessage.length;i++){
			System.out.println("��  "+(i+1)+"���ʼ������⣺ "+subject);
			System.out.println("�� " + (i+1) + "���ʼ��ķ����˵�ַ��" + sender); 
			System.out.println("�ʼ����⣺" +allMessage[i].getSubject());
			System.out.println("�ʼ����ݣ�" +allMessage[i].getContent().toString());
			System.out.println("�ʼ��������ڣ�"+allMessage[i].getSentDate());
			System.out.println("********************************************");
		}
		folder.close(false);
		store.close();
		return feedback;
	}
}
